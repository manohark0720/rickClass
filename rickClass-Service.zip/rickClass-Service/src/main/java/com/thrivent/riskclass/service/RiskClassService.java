package com.thrivent.riskclass.service;

public interface RiskClassService {
	


	String getRickClass(int age, String height, Integer wheight, String tobaccoUser, int tobaccoLastUsed);

}
