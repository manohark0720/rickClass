package com.thrivent.riskclass.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.thrivent.riskclass.service.RiskClassService;

@RestController
@RequestMapping("rest")
public class RiskClassController {

	@Autowired
	RiskClassService riskClassService;

	@GetMapping("/age/{age}/height/{height}/wheight/{wheight}/tobaccoUser/{tobaccoUser}/tobaccoLastUsed/{tobaccoLastUsed}")
	public String getRickClass(@PathVariable String age, @PathVariable String height, @PathVariable String wheight,@PathVariable String tobaccoUser,
			@PathVariable String tobaccoLastUsed) {
		
		
		return riskClassService.getRickClass(Integer.parseInt(age), height, Integer.parseInt(wheight), tobaccoUser, Integer.parseInt(tobaccoLastUsed));

	}

}
