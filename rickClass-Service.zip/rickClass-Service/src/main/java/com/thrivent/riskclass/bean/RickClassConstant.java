package com.thrivent.riskclass.bean;

public final class RickClassConstant {
	
	public static final String NO_QUOTE = "No Quote";
	public static final String HEIGHT = "Height";
	public static final String RATED = "Rated";
	public static final String PREFERRED = "Preferred";
	public static final String PREFERRED_BEST = "Preferred Best";
	public static final String STANDARD = "Standard";
	public static final String SUPER_PREFERRED = "Super Preferred";
	public static final String TOBACCO = " Non Tobacco";
	
	 
	
	

}
