package com.thrivent.riskclass.bean;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("session")
public class RickClassBean {
	
	private Map<String ,String> sample1=new HashMap<String ,String>();
	
	
	
	
	
	
	

}
