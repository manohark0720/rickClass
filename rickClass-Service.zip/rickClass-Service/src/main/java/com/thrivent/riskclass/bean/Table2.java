package com.thrivent.riskclass.bean;

public class Table2 {

	private String height;
	private String preferredBest;
	private String superPreferred;
	private String preferred;
	private String standard;
	private String rated;
	
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getPreferredBest() {
		return preferredBest;
	}
	public void setPreferredBest(String preferredBest) {
		this.preferredBest = preferredBest;
	}
	public String getSuperPreferred() {
		return superPreferred;
	}
	public void setSuperPreferred(String superPreferred) {
		this.superPreferred = superPreferred;
	}
	public String getPreferred() {
		return preferred;
	}
	public void setPreferred(String preferred) {
		this.preferred = preferred;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getRated() {
		return rated;
	}
	public void setRated(String rated) {
		this.rated = rated;
	}
	
}
