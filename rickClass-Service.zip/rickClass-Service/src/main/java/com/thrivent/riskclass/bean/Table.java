package com.thrivent.riskclass.bean;

import java.util.List;

public class Table {
	
	private String height;
	private List<Integer> preferredBest;
	private List<Integer> superPreferred;
	private List<Integer> preferred;
	private List<Integer> standard;
	private List<Integer> rated;
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public List<Integer> getPreferredBest() {
		return preferredBest;
	}
	public void setPreferredBest(List<Integer> preferredBest) {
		this.preferredBest = preferredBest;
	}
	public List<Integer> getSuperPreferred() {
		return superPreferred;
	}
	public void setSuperPreferred(List<Integer> superPreferred) {
		this.superPreferred = superPreferred;
	}
	public List<Integer> getPreferred() {
		return preferred;
	}
	public void setPreferred(List<Integer> preferred) {
		this.preferred = preferred;
	}
	public List<Integer> getStandard() {
		return standard;
	}
	public void setStandard(List<Integer> standard) {
		this.standard = standard;
	}
	public List<Integer> getRated() {
		return rated;
	}
	public void setRated(List<Integer> rated) {
		this.rated = rated;
	}
	

}
